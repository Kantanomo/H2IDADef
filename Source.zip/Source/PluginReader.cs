﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;

namespace TagDefToIDADef
{
    public static class PluginReader
    {
        public static XmlTextReader xr;
        public static List<string> Revisions = new List<string>();
        public static string Class;
        public static string Author;
        public static string Version;
        public static int idn = 0;
        
        public static string Read(string class_)
        {
            #region Reading
            string C = class_.Replace('*', '!');
            C = C.Replace('/', '_');
            C = C.Replace('\\', '_');
            C = C.Replace('<', '_');
            C = C.Replace('>', '_');
            var GetDirectory = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
            string Location = GetDirectory + "\\Plugins\\" + C + ".Xml";
            var preoutput = "";
            var output = string.Format("struct struct_{0}\r\n{{\r\n", C);
            var rput = new StructBuilder(C);
            var poffset = 0;
            var ooffset = new int[40];
            var pid = 0;
            var routput = "";
            var loffset = 92293232;
            if (!File.Exists(Location))
            {
                return null;
            }
            else
            {
                xr = new XmlTextReader(new FileStream(Location, FileMode.Open, FileAccess.Read, FileShare.Read));

                Class = "";
                Author = "";
                Version = "";
                bool isReflexive = false;
                string reflexiveName = "";
                while (xr.Read())
                {
                    if (xr.Depth == 1)
                    {
                        if (isReflexive)
                        {
                            isReflexive = false;
                            rput.EndReflexive();
                            poffset = ooffset[xr.Depth];
                            ooffset[xr.Depth] = 0;
                        }
                    }

                    switch (xr.NodeType)
                    {
                        case XmlNodeType.Element:
                            {
                                int aOffset = Convert.ToInt32(xr.GetAttribute("offset"));

                                if (aOffset != poffset)
                                {
                                    //output += $"_BYTE padding_{pid}[{aOffset - poffset}];\r\n";
                                    //rput.AddDef($"_BYTE padding_{pid}[{aOffset - poffset}]", aOffset - poffset);
                                    rput.AddPadding(aOffset - poffset);
                                    poffset += aOffset - poffset;
                                    pid++;
                                }
                                switch (xr.Name.ToLower())
                                {
                                    case "plugin":
                                        {
                                            Class = xr.GetAttribute("class");
                                            Author = xr.GetAttribute("author");
                                            Version = xr.GetAttribute("version");
                                            break;
                                        }
                                    case "revision":
                                        {
                                            Revisions.Add(xr.ReadElementString());
                                            break;
                                        }
                                    case "byte":
                                        {
                                            string Description = xr.GetAttribute("name").Replace(" ", "_");
                                            int Offset = Convert.ToInt32(xr.GetAttribute("offset"));
                                            if (loffset == Offset)
                                                break;
                                            loffset = aOffset;
                                            rput.AddDef($"_BYTE {Description}", 1);
                                            //output += $"_BYTE {Description};\r\n";
                                            poffset += 1;
                                            break;
                                        }
                                    case "short":
                                        {
                                            string Description = xr.GetAttribute("name").Replace(" ", "_");
                                            int Offset = Convert.ToInt32(xr.GetAttribute("offset"));
                                            if (loffset == Offset)
                                                break;
                                            loffset = aOffset;
                                            rput.AddDef($"_WORD {Description}", 2);
                                            //output += $"_WORD {Description};\r\n";
                                            poffset += 2;
                                            
                                            break;
                                        }
                                    case "ushort":
                                        {
                                            string Description = xr.GetAttribute("name");
                                            int Offset = Convert.ToInt32(xr.GetAttribute("offset"));
                                            if (loffset == Offset)
                                                break;
                                            loffset = aOffset;
                                            break;
                                        }
                                    case "int":
                                        {
                                            string Description = xr.GetAttribute("name").Replace(" ", "_");
                                            int Offset = Convert.ToInt32(xr.GetAttribute("offset"));
                                            if (loffset == Offset)
                                                break;
                                            loffset = aOffset;
                                            rput.AddDef($"_DWORD {Description}", 4);
                                            //output += $"_DWORD {Description};\r\n";
                                            poffset += 4;
                                            break;
                                        }
                                    case "uint":
                                        {
                                            string Description = xr.GetAttribute("name");
                                            int Offset = Convert.ToInt32(xr.GetAttribute("offset"));
                                            if (loffset == Offset)
                                                break;
                                            loffset = aOffset;
                                            break;
                                        }
                                    case "float":
                                        {
                                            string Description = xr.GetAttribute("name").Replace(" ", "_");
                                            int Offset = Convert.ToInt32(xr.GetAttribute("offset"));
                                            if (loffset == Offset)
                                                break;
                                            loffset = aOffset;
                                            rput.AddDef($"float {Description}", 4);
                                            //output += $"float {Description};\r\n";
                                            poffset += 4;
                                            break;
                                        }
                                    case "string":
                                        {
                                            string Description = xr.GetAttribute("name");
                                            int Offset = Convert.ToInt32(xr.GetAttribute("offset"));
                                            if (loffset == Offset)
                                                break;
                                            loffset = aOffset;
                                            int Length = Convert.ToInt32(xr.GetAttribute("length"));
                                            break;
                                        }
                                    case "unknown":
                                        {
                                            string Description = xr.GetAttribute("name");
                                            int Offset = Convert.ToInt32(xr.GetAttribute("offset"));
                                            if (loffset == Offset)
                                                break;
                                            loffset = aOffset;
                                            break;
                                        }
                                    case "long":
                                        {
                                            string Description = xr.GetAttribute("name");
                                            int Offset = Convert.ToInt32(xr.GetAttribute("offset"));
                                            if (loffset == Offset)
                                                break;
                                            loffset = aOffset;
                                            break;
                                        }
                                    case "ident":
                                        {
                                            string Description = xr.GetAttribute("name").Replace(" ", "_");
                                            int Offset = Convert.ToInt32(xr.GetAttribute("offset"));
                                            if (loffset == Offset)
                                                break;
                                            loffset = aOffset;
                                            rput.AddDef($"_DWORD {Description}_Class", 4);
                                            rput.AddDef($"_DWORD {Description}", 4);
                                            //output += $"char {Description}_Class[4];\r\n";
                                            //output += $"_DWORD {Description}_Datum;\r\n";
                                            poffset += 8;
                                            break;
                                        }
                                    case "reflexive":
                                        {
                                            string Description = xr.GetAttribute("name").Replace(" ", "_");
                                            int Offset = Convert.ToInt32(xr.GetAttribute("offset"));
                                            if (loffset == Offset)
                                                break;
                                            loffset = aOffset;
                                            int Size = Convert.ToInt32(xr.GetAttribute("size"));
                                            if (xr.Depth == 1)
                                                reflexiveName = Description + "_";
                                            else
                                                reflexiveName += Description + "_";
                                            isReflexive = true;
                                            //xr.Skip();
                                            
                                            rput.AddDef($"_DWORD {Description}_Count", 4);
                                            rput.AddDef($"_DWORD {Description}_Offset", 4);
                                            rput.AddReflexive(Description);
                                            //output += $"_DWORD {Description}_Count;\r\n";
                                            //output += $"_DWORD {Description}_Offset;\r\n";
                                            poffset += 8;
                                            ooffset[xr.Depth] = poffset;
                                            poffset = 0;
                                            break;
                                        }
                                    case "stringid":
                                        {
                                            string Description = xr.GetAttribute("name").Replace(" ", "_");
                                            int Offset = Convert.ToInt32(xr.GetAttribute("offset"));
                                            if (loffset == Offset)
                                                break;
                                            loffset = aOffset;
                                            rput.AddDef($"_DWORD {Description}", 4);
                                            //output += $"_DWORD {Description}_datum;\r\n";
                                            poffset += 4;
                                            break;
                                        }
                                    case "enum8":
                                        {
                                            string Description = xr.GetAttribute("name").Replace(" ", "_");
                                            int Offset = Convert.ToInt32(xr.GetAttribute("offset"));
                                            if (loffset == Offset)
                                                break;
                                            loffset = aOffset;
                                            preoutput += $"auto id_{idn} = add_enum(-1, \"{Description}\", 0);\r\n";
                                            Dictionary<string, int> EnumVals = new Dictionary<string, int>();
                                            XmlReader x = xr.ReadSubtree();
                                            while (x.Read())
                                            {
                                                switch (x.Name.ToLower())
                                                {
                                                    case "option":
                                                    {
                                                        preoutput +=
                                                            $"add_enum_member(id_{idn}, \"{Description}_{xr.GetAttribute("name").Replace(" ", "_")}\", 0x{ Convert.ToInt32(xr.GetAttribute("value")):X}, -1);\r\n";
                                                            //EnumVals.Add(xr.GetAttribute("name"), Convert.ToInt32(xr.GetAttribute("value")));
                                                            break;
                                                        }
                                                }
                                            }

                                            //output += $"{Description} {Description};\r\n";
                                            //output += $"_BYTE {Description};\r\n";
                                            rput.AddDef($"_BYTE {Description}", 1);
                                            poffset += 1;
                                            idn++;
                                            break;
                                        }
                                    case "enum16":
                                        {
                                            string Description = xr.GetAttribute("name").Replace(" ", "_");
                                            int Offset = Convert.ToInt32(xr.GetAttribute("offset"));
                                            preoutput += $"auto id_{idn} = add_enum(-1, \"{Description}\", 0);\r\n";
                                            if (loffset == Offset)
                                                break;
                                            loffset = aOffset;
                                            Dictionary<string, int> EnumVals = new Dictionary<string, int>();
                                            XmlReader x = xr.ReadSubtree();
                                            while (x.Read())
                                            {
                                                switch (x.Name.ToLower())
                                                {
                                                    case "option":
                                                    {
                                                        preoutput +=
                                                            $"add_enum_member(id_{idn}, \"{Description}_{xr.GetAttribute("name").Replace(" ", "_")}\", 0x{ Convert.ToInt32(xr.GetAttribute("value")):X}, -1);\r\n";
                                                        //EnumVals.Add(xr.GetAttribute("name"), Convert.ToInt32(xr.GetAttribute("value")));
                                                        break;
                                                    }
                                                }
                                            }

                                            //output += $"{Description} {Description};\r\n";
                                            //output += $"_WORD {Description};\r\n";
                                            rput.AddDef($"_WORD {Description}", 2);
                                            poffset += 2;
                                            idn++;
                                            break;
                                        }
                                    case "enum32":
                                        {
                                            string Description = xr.GetAttribute("name").Replace(" ", "_");
                                            int Offset = Convert.ToInt32(xr.GetAttribute("offset"));
                                            preoutput += $"auto id_{idn} = add_enum(-1, \"{Description}\", 0);\r\n";
                                            if (loffset == Offset)
                                                break;
                                            loffset = aOffset;
                                            Dictionary<string, int> EnumVals = new Dictionary<string, int>();
                                            XmlReader x = xr.ReadSubtree();
                                            while (x.Read())
                                            {
                                                switch (x.Name.ToLower())
                                                {
                                                    case "option":
                                                    {
                                                        preoutput +=
                                                            $"add_enum_member(id_{idn}, \"{Description}_{xr.GetAttribute("name").Replace(" ", "_")}\", 0x{ Convert.ToInt32(xr.GetAttribute("value")):X}, -1);\r\n";
                                                        //EnumVals.Add(xr.GetAttribute("name"), Convert.ToInt32(xr.GetAttribute("value")));
                                                        break;
                                                    }
                                                }
                                            }

                                            //output += $"{Description} {Description};\r\n";
                                            rput.AddDef($"_DWORD {Description}", 4);
                                            //output += $"_DWORD {Description};\r\n";
                                            poffset += 4;
                                            idn++;
                                            break;
                                        }
                                    case "bitmask8":
                                        {
                                            string Description = xr.GetAttribute("name").Replace(" ", "_");
                                            int Offset = Convert.ToInt32(xr.GetAttribute("offset"));
                                            if (loffset == Offset)
                                                break;
                                            loffset = aOffset;
                                            List<string> Items = new List<string>();
                                            List<int> Values = new List<int>();
                                            XmlReader x = xr.ReadSubtree();
                                            while (x.Read())
                                            {
                                                switch (x.Name.ToLower())
                                                {
                                                    case "option":
                                                        {
                                                            Items.Add(xr.GetAttribute("name"));
                                                            Values.Add(Convert.ToInt32(xr.GetAttribute("value")));
                                                            break;
                                                        }
                                                }
                                            }
                                            rput.AddDef($"_BYTE {Description}", 1);
                                            //output += $"_BYTE {Description};\r\n";
                                            poffset += 1;
                                            break;
                                        }
                                    case "bitmask16":
                                        {
                                            string Description = xr.GetAttribute("name").Replace(" ", "_");
                                            int Offset = Convert.ToInt32(xr.GetAttribute("offset"));
                                            if (loffset == Offset)
                                                break;
                                            loffset = aOffset;
                                            List<string> Items = new List<string>();
                                            List<int> Values = new List<int>();
                                            XmlReader x = xr.ReadSubtree();
                                            while (x.Read())
                                            {
                                                switch (x.Name.ToLower())
                                                {
                                                    case "option":
                                                        {
                                                            Items.Add(xr.GetAttribute("name"));
                                                            Values.Add(Convert.ToInt32(xr.GetAttribute("value")));
                                                            break;
                                                        }
                                                }
                                            }
                                            rput.AddDef($"_WORD {Description}", 2);
                                            //output += $"_WORD {Description};\r\n";
                                            poffset += 2;
                                            break;
                                        }
                                    case "bitmask32":
                                        {
                                            string Description = xr.GetAttribute("name").Replace(" ", "_");
                                            int Offset = Convert.ToInt32(xr.GetAttribute("offset"));
                                            if (loffset == Offset)
                                                break;
                                            loffset = aOffset;
                                            List<string> Items = new List<string>();
                                            List<int> Values = new List<int>();
                                            XmlReader x = xr.ReadSubtree();
                                            while (x.Read())
                                            {
                                                switch (x.Name.ToLower())
                                                {
                                                    case "option":
                                                        {
                                                            Items.Add(xr.GetAttribute("name"));
                                                            Values.Add(Convert.ToInt32(xr.GetAttribute("value")));
                                                            break;
                                                        }
                                                }
                                            }
                                            rput.AddDef($"_DWORD {Description}", 4);
                                            //output += $"_DWORD {Description};\r\n";
                                            poffset += 4;
                                            break;
                                        }
                                    case "string32":
                                        {
                                            //string Description = xr.GetAttribute("name");
                                            //int Offset = Convert.ToInt32(xr.GetAttribute("offset")) + map.SelectedTag.MetaOffset;
                                            //map.br.BaseStream.Position = Offset;
                                            //string Value = new string(map.br.ReadChars(32));
                                            //String s = new String(Description, Offset, ValueringType.String32);
                                            //Controls.Add(s);
                                            //s.Dock = DockStyle.Top;
                                            //s.BringToFront();
                                            break;
                                        }
                                    case "string64":
                                        {
                                            //string Description = xr.GetAttribute("name");
                                            //int Offset = Convert.ToInt32(xr.GetAttribute("offset")) + map.SelectedTag.MetaOffset;
                                            //map.br.BaseStream.Position = Offset;
                                            //string Value = new string(map.br.ReadChars(64));
                                            //String s = new String(Description, Offset, ValueringType.String64);
                                            //Controls.Add(s);
                                            //s.Dock = DockStyle.Top;
                                            //s.BringToFront();
                                            break;
                                        }
                                    case "unicode64":
                                        {
                                            //string Description = xr.GetAttribute("name");
                                            //int Offset = Convert.ToInt32(xr.GetAttribute("offset")) + map.SelectedTag.MetaOffset;
                                            //map.br.BaseStream.Position = Offset;
                                            //string Value = "";
                                            //for (int i = 0; i < 32; i++)
                                            //{
                                            //    Value += Convert.ToChar(map.br.ReadByte());
                                            //    map.br.BaseStream.Position++;
                                            //}
                                            //String s = new String(Description, Offset, ValueringType.Unicode64);
                                            //Controls.Add(s);
                                            //s.Dock = DockStyle.Top;
                                            //s.BringToFront();
                                            break;
                                        }
                                    case "unicode256":
                                        {
                                            //string Description = xr.GetAttribute("name");
                                            //int Offset = Convert.ToInt32(xr.GetAttribute("offset")) + map.SelectedTag.MetaOffset;
                                            //map.br.BaseStream.Position = Offset;
                                            //string Value = "";
                                            //for (int i = 0; i < 128; i++)
                                            //{
                                            //    Value += Convert.ToChar(map.br.ReadByte());
                                            //    map.br.BaseStream.Position++;
                                            //}
                                            //String s = new String(Description, Offset, ValueringType.Unicode256);
                                            //Controls.Add(s);
                                            //s.Dock = DockStyle.Top;
                                            //s.BringToFront();
                                            break;
                                        }
                                }
                                break;
                            }
                    }
                }

                xr.Close();

                //Load Controls
                return rput.Return;
            }
            #endregion
        }
    }

    public class StructBuilder
    {
        private StringWriter _return = new StringWriter();
        private Dictionary<string, StringWriter> _reflexives = new Dictionary<string, StringWriter>();
        private string _currentReflexive = "";
        private int cSize = 0;
        private string _name;
        private List<string> uniquer = new List<string>();
        private List<string> ouniquer = new List<string>();
        public StructBuilder(string name)
        {
            _name = SanatizeString(name);
            _return.WriteLine($"struct struct_{_name}");
            _return.WriteLine("{");
        }

        public void AddReflexive(string name)
        {
            _currentReflexive = SanatizeString(name);
            if (_reflexives.ContainsKey(_currentReflexive))
            {
                for (int i = 0; i < int.MaxValue; i++)
                {
                    if (!_reflexives.ContainsKey(_currentReflexive + $"_{i}"))
                    {
                        _currentReflexive = _currentReflexive + $"_{i}";
                        break;
                    }
                }
            }
            _reflexives.Add(_currentReflexive, new StringWriter());
            _reflexives[_currentReflexive].WriteLine($"struct struct_tag_{_name}_{_currentReflexive}");
            _reflexives[_currentReflexive].WriteLine("{");
            ouniquer = uniquer;
            uniquer = new List<string>();
        }

        public void EndReflexive()
        {
            _currentReflexive = "";
            uniquer = ouniquer;
        }
        public void AddDef(string input, int size)
        {
            var ti = SanatizeString(input);
            if (uniquer.Contains(ti))
            {
                for (int i = 0; i < int.MaxValue; i++)
                {
                    if (!uniquer.Contains(ti + $"_{i}"))
                    {
                        ti = ti + $"_{i}";
                        break;
                    }
                }
            }
            if (_currentReflexive == "")
                _return.WriteLine($"\t{ti};");// #{size}:{cSize}");
            else
                _reflexives[_currentReflexive].WriteLine($"\t{ti};");
            cSize += size;
            uniquer.Add(ti);
        }

        private int padId = 0;
        public void AddPadding(int size)
        {
            if(_currentReflexive == "")
                _return.WriteLine($"\t_BYTE padding_{padId++}[{size}];");// #{size}:{cSize}");
            else
                _reflexives[_currentReflexive].WriteLine($"\t_BYTE padding_{padId++}[{size}];");
            cSize += size;
        }

        public string Return
        {
            get
            {
                var ret = _return + "};\r\n";
                foreach (var reflexivesValue in _reflexives.Values)
                    ret += reflexivesValue + "};\r\n";
                return ret;
            }
        }
        private static string SanatizeString(string input)
        {
            var matches = DigitRegex.Matches(input);

            if (matches.Count != 0)
                input = matches.Cast<Match>().Reverse().Aggregate(input, (current, match) => Replace(current, match.Index, match.Length, NumberToWords(int.Parse(match.Value))));
                
            return input.Replace("(", "").Replace(")", "").Replace(".", "_").Replace("-","_");
        }
        private static string Replace(string s, int index, int length, string replacement)
        {
            var builder = new StringBuilder();
            builder.Append(s.Substring(0, index));
            builder.Append(replacement);
            builder.Append(s.Substring(index + length));
            return builder.ToString();
        }
        private static Regex DigitRegex = new Regex(@"\d+");
        private static string NumberToWords(int number)
        {
            if (number == 0)
                return "zero";

            if (number < 0)
                return "minus " + NumberToWords(Math.Abs(number));

            string words = "";

            if ((number / 1000000) > 0)
            {
                words += NumberToWords(number / 1000000) + " million ";
                number %= 1000000;
            }

            if ((number / 1000) > 0)
            {
                words += NumberToWords(number / 1000) + " thousand ";
                number %= 1000;
            }

            if ((number / 100) > 0)
            {
                words += NumberToWords(number / 100) + " hundred ";
                number %= 100;
            }

            if (number > 0)
            {
                if (words != "")
                    words += "and ";

                var unitsMap = new[] { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen" };
                var tensMap = new[] { "zero", "ten", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety" };

                if (number < 20)
                    words += unitsMap[number];
                else
                {
                    words += tensMap[number / 10];
                    if ((number % 10) > 0)
                        words += "-" + unitsMap[number % 10];
                }
            }

            return words;
        }
    }
}
