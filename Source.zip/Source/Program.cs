﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TagDefToIDADef
{
    class Program
    {
        static void Main(string[] args)
        {
            var GetDirectory = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
            var o = "";
            foreach (var file in Directory.GetFiles(GetDirectory + "\\Plugins"))
            {
                var C = file.Split('\\').Last().Split('.').First();
                var b = Path.Combine(GetDirectory + "\\IDADefs\\", $"{C}.txt");//$"${GetDirectory}\\IDADefs\\{C}.txt";
                File.WriteAllText(b, PluginReader.Read(file.Split('\\').Last().Split('.').First()));
            }
            //File.WriteAllText("test.txt", PluginReader.Read("weap"));

            while (true)
            {
                Thread.Sleep(1000);
            }
        }
    }
}
